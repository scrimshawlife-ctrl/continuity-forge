# Minimal Retrieval Example

**brief.yaml** — a tiny low-budget melodrama brief.

**expected-receipt.yaml** — the retrieval output you should get when running:

```bash
python ../scripts/retrieve_symbolic_patterns.py --brief brief.yaml
```

Use this as a smoke test after installing the skill.
